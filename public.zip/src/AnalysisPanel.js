
import React from 'react';

const AnalyisPanel = () => {

  

  return (
    <div style={{
      height: 'calc(45vh)',
      width: '250px', 
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      outline: '1px solid #cfcfcf',
      padding: '50px',
      outlineOffset: '-2px',
      backgroundColor: '#222222',
    }}>
      
      
    </div>
  );
};

export default AnalyisPanel;