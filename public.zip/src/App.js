// App.js
import React, { useState } from 'react';
import './App.css';
import MapPanel from './MapPanel';
import KPIPanel from './KPIPanel';
import TablePanel from './TablePanel';
import AnalyisPanel from './AnalysisPanel';
import ChartPanel from './ChartPanel';
import Navbar from './Navbar';

function App() {
  const [selectedValue, setSelectedValue] = useState("ECC Complaints");

  const handleChange = (event) => {
    setSelectedValue(event.target.value);
  };

  const options = [
    "ECC Complaints",
    "BAU RW Complaints",
    "BAU NRW Complaints"
  ];

  return (
    <div className="App">
      <Navbar selectedValue={selectedValue} handleChange={handleChange} options={options} />
      <div style={{ display: "flex" }}>
        <div style={{ flex: 1 }}>
          <MapPanel />
          <TablePanel />
        </div>
        <div>
          <KPIPanel selectedValue={selectedValue} />
        </div>
        <div>
          <ChartPanel selectedValue={selectedValue} />
          <AnalyisPanel />
        </div>
      </div>
    </div>
  );
}

export default App;
